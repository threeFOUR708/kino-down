package com.kinodown.app

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.Dialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.text.SpannableString
import android.text.Spanned
import android.text.TextUtils
import android.text.style.BackgroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.yausername.youtubedl_android.mapper.VideoInfo
import java.io.File
import java.net.URLEncoder

class MainActivity : Activity() {

    private val INK = Fx.INK
    private val PINK = Fx.PINK
    private val SUN = Fx.SUN
    private val MINT = Fx.MINT
    private val LAV = Fx.LAV
    private val CREAM = Fx.CREAM
    private val PAPER = Fx.PAPER
    private val WHITE = Fx.WHITE
    private val SOFT = Color.argb(150, 43, 35, 64)
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    private val PAWS = listOf("🐾", "♥", "🦴", "🐟")

    private val sites = listOf(
        Triple("Google", "https://www.google.com", "https://www.google.com/search?q=%s"),
        Triple("Images", "https://www.google.com/imghp", "https://www.google.com/search?tbm=isch&q=%s"),
        Triple("YouTube", "https://m.youtube.com", "https://m.youtube.com/results?search_query=%s"),
        Triple("TikTok", "https://www.tiktok.com", "https://www.tiktok.com/search?q=%s"),
        Triple("Facebook", "https://m.facebook.com", "https://m.facebook.com/search/top/?q=%s"),
        Triple("Instagram", "https://www.instagram.com", "https://www.instagram.com/explore/search/keyword/?q=%s"),
        Triple("X", "https://x.com", "https://x.com/search?q=%s")
    )

    private class Row(val card: LinearLayout, val title: TextView, val status: TextView, val bar: Bar, val btns: LinearLayout) {
        var state = -1
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var fxRoot: FrameLayout
    private lateinit var homePage: View
    private lateinit var browsePage: View
    private lateinit var dlPage: View
    private lateinit var morePage: View
    private val more = MoreTab(this)
    private lateinit var navItems: List<TextView>
    private lateinit var badge: TextView
    private lateinit var urlBox: EditText
    private lateinit var searchBox: EditText
    private lateinit var webHost: FrameLayout
    private lateinit var chipRow: LinearLayout
    private lateinit var dlList: LinearLayout
    private lateinit var dlEmpty: TextView
    private lateinit var engineStatus: TextView
    private val webs = HashMap<String, WebView>()
    private val anims = ArrayList<ValueAnimator>()
    private val rows = HashMap<String, Row>()
    private var site = "YouTube"
    private var tab = 0
    private var fullView: View? = null
    private var fullCb: WebChromeClient.CustomViewCallback? = null
    private var renderPending = false

    private val ctx: Context get() = this
    private fun dp(v: Int) = Fx.dp(this, v)
    private fun dpf(v: Float) = Fx.dpf(this, v)
    internal fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    private fun <T : ValueAnimator> anim(a: T): T {
        anims.add(a)
        return a
    }

    private val burstCb: (Float, Float) -> Unit = { x, y -> Fx.burst(fxRoot, x, y, PAWS) }

    internal fun txt(t: CharSequence, size: Float = 14f, color: Int = INK, bold: Boolean = false) = TextView(ctx).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    internal fun btn(t: String, fill: Int, fg: Int = INK, burst: Boolean = true, click: () -> Unit) = TextView(ctx).apply {
        text = t
        setTextColor(fg)
        typeface = Typeface.DEFAULT_BOLD
        textSize = 15f
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(13), dp(16), dp(13))
        Fx.cute(this, fill, 18, 5)
        Fx.press(this, if (burst) burstCb else null)
        setOnClickListener { click() }
    }

    internal fun pill(t: String, fill: Int, fg: Int = INK, click: () -> Unit) = TextView(ctx).apply {
        text = t
        setTextColor(fg)
        typeface = Typeface.DEFAULT_BOLD
        textSize = 12.5f
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(9), dp(14), dp(9))
        Fx.cute(this, fill, 99, 3)
        Fx.press(this, burstCb)
        setOnClickListener { click() }
    }

    private fun LinearLayout.add(v: View, top: Int = 0, w: Int = MATCH, h: Int = WRAP, weight: Float = 0f, left: Int = 0) {
        addView(v, LinearLayout.LayoutParams(w, h, weight).apply {
            topMargin = dp(top)
            leftMargin = dp(left)
        })
    }

    // ================================================================= lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = CREAM
        window.navigationBarColor = CREAM
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        CookieManager.getInstance().setAcceptCookie(true)

        fxRoot = FrameLayout(ctx)
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = Fx.dotted(this@MainActivity)
        }
        homePage = buildHome()
        browsePage = buildBrowse()
        dlPage = buildDownloads()
        morePage = more.build()
        val pages = FrameLayout(ctx)
        pages.addView(homePage, FrameLayout.LayoutParams(MATCH, MATCH))
        pages.addView(browsePage, FrameLayout.LayoutParams(MATCH, MATCH))
        pages.addView(dlPage, FrameLayout.LayoutParams(MATCH, MATCH))
        pages.addView(morePage, FrameLayout.LayoutParams(MATCH, MATCH))
        col.add(pages, h = 0, weight = 1f)
        col.add(buildNav())
        fxRoot.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(fxRoot)

        showSite("YouTube")
        show(0)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        Engine.autoUpdate()
        more.startup()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        Engine.onChange = { requestRender() }
        renderDownloads()
    }

    override fun onPause() {
        super.onPause()
        Engine.onChange = null
    }

    override fun onDestroy() {
        anims.forEach { it.cancel() }
        webs.values.forEach { it.destroy() }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (fullView != null) { exitFull(); return }
        if (tab == 1) {
            val w = webs[site]
            if (w != null && w.canGoBack()) { w.goBack(); return }
        }
        if (tab != 0) { show(0); return }
        super.onBackPressed()
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            val u = extractUrl(t)
            if (u != null) {
                urlBox.setText(u)
                show(0)
                sheet(u)
            }
        }
    }

    private fun extractUrl(t: String): String? = Regex("https?://\\S+").find(t)?.value

    // ================================================================= navigation
    private fun buildNav(): View {
        val holder = FrameLayout(ctx).apply { setPadding(dp(14), dp(6), dp(14), dp(10)) }
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            Fx.cute(this, WHITE, 26, 5)
        }
        val labels = listOf("🏠" to "Home", "🌐" to "Browse", "⬇️" to "Downloads", "⚙️" to "More")
        navItems = labels.mapIndexed { i, (e, l) ->
            val t = TextView(ctx).apply {
                text = SpannableString("$e\n$l").apply {
                    setSpan(RelativeSizeSpan(1.8f), 0, e.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                textSize = 11f
                setTextColor(INK)
                setPadding(0, dp(7), 0, dp(6))
                setOnClickListener { show(i) }
            }
            Fx.press(t, burstCb)
            val cell = FrameLayout(ctx)
            cell.addView(t, FrameLayout.LayoutParams(MATCH, WRAP))
            if (i == 2) {
                badge = TextView(ctx).apply {
                    text = "0"
                    textSize = 10f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(WHITE)
                    gravity = Gravity.CENTER
                    minWidth = dp(19)
                    minHeight = dp(19)
                    setPadding(dp(4), 0, dp(4), 0)
                    Fx.cute(this, PINK, 99, 0)
                    visibility = View.GONE
                }
                cell.addView(badge, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply { rightMargin = dp(14) })
            }
            bar.add(cell, w = 0, weight = 1f)
            t
        }
        holder.addView(bar, FrameLayout.LayoutParams(MATCH, WRAP))
        return holder
    }

    internal fun show(i: Int) {
        tab = i
        homePage.visibility = if (i == 0) View.VISIBLE else View.GONE
        browsePage.visibility = if (i == 1) View.VISIBLE else View.GONE
        dlPage.visibility = if (i == 2) View.VISIBLE else View.GONE
        morePage.visibility = if (i == 3) View.VISIBLE else View.GONE
        navItems.forEachIndexed { k, t ->
            t.background = if (k == i) GradientDrawable().apply {
                setColor(SUN)
                cornerRadius = dpf(20f)
            } else null
        }
        if (i == 2) renderDownloads()
        if (i == 3) more.render()
    }

    // ================================================================= HOME
    private fun buildHome(): View {
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(36), dp(18), dp(18))
            clipChildren = false
            clipToPadding = false
        }
        val brand = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            clipChildren = false
            setPadding(0, dp(10), dp(10), dp(8))
        }
        brand.add(txt("KINO", 22f, INK, true).apply { letterSpacing = 0.05f }, w = WRAP)
        val down = txt("DOWN", 22f, WHITE, true).apply {
            setPadding(dp(11), dp(2), dp(11), dp(2))
            Fx.cute(this, PINK, 12, 3)
            rotation = -4f
        }
        brand.add(down, w = WRAP, left = 8)
        anim(ObjectAnimator.ofFloat(down, "rotation", -4f, 3f).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
        }).start()
        col.add(brand)

        col.add(TextView(ctx).apply {
            text = SpannableString("Download anything\nfrom any link").apply {
                setSpan(BackgroundColorSpan(SUN), 9, 17, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(INK)
        }, 22)
        col.add(txt("Paste a link or search — it shows up instantly 🐾", 14.5f, SOFT).apply { gravity = Gravity.CENTER }, 10)
        col.add(buildPerch(), 6, h = dp(62))

        urlBox = EditText(ctx).apply {
            hint = "Paste a link or type to search…\nYouTube, Instagram, TikTok, Facebook, X"
            minLines = 3
            gravity = Gravity.TOP
            textSize = 14.5f
            setTextColor(INK)
            setHintTextColor(Color.argb(102, 43, 35, 64))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            Fx.cute(this, PAPER, 18, 0)
        }
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            Fx.cute(this, WHITE, 28, 5)
        }
        card.add(urlBox)
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        row.add(btn("Paste", SUN) { paste() }, w = 0, weight = 1f)
        row.add(btn("⚡ GET VIDEO", PINK, WHITE) { getVideo() }, w = 0, weight = 2f, left = 10)
        card.add(row, 14)
        col.add(card, -22)

        val guide = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(16))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#2B1B66"), Color.parseColor("#1B1240"))
            ).apply {
                cornerRadius = dpf(22f)
                setStroke(dp(2), SUN)
            }
        }
        guide.add(txt("✨ BROWSE & SAVE", 15f, SUN, true))
        val chips = Flow(ctx, dp(6))
        listOf("Google", "Images", "YouTube", "TikTok", "Facebook", "Instagram", "X").forEach { n ->
            chips.addView(txt(n, 12f, WHITE, true).apply {
                setPadding(dp(10), dp(4), dp(10), dp(4))
                background = GradientDrawable().apply {
                    setColor(Color.argb(40, 255, 255, 255))
                    cornerRadius = dpf(20f)
                    setStroke(dp(1), Color.argb(80, 255, 255, 255))
                }
            })
        }
        guide.add(chips, 10)
        guideStep(guide, "1", "Find a video or image")
        guideStep(guide, "2", "Tap the ⬇ button")
        guideStep(guide, "3", "Pick a quality. Done!")
        guide.add(txt("Tip: long-press any image to save it.", 12f, Color.argb(170, 255, 255, 255)), 10)
        col.add(guide, 20)

        engineStatus = txt("", 12f, SOFT)
        col.add(pill("🔄 Update downloader", MINT) { updateEngine() }, 20, w = WRAP)
        col.add(engineStatus, 8)
        col.add(txt("Tip: if a site stops working, tap Update. Sites change often.", 12f, SOFT), 4)
        return ScrollView(ctx).apply {
            clipChildren = false
            addView(col)
        }
    }

    private fun guideStep(parent: LinearLayout, n: String, s: String) {
        val r = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val c = txt(n, 12f, INK, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(SUN)
            }
        }
        r.add(c, w = dp(24), h = dp(24))
        r.add(txt(s, 13.5f, WHITE), w = 0, weight = 1f, left = 10)
        parent.add(r, 8)
    }

    /** pets pop out from behind the paste card as round stickers, then sway gently */
    private fun buildPerch(): View {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            clipChildren = false
            clipToPadding = false
        }
        val fills = intArrayOf(
            Color.parseColor("#FFE0EA"), Color.parseColor("#FFF0C2"),
            Color.parseColor("#D6F7EC"), Color.parseColor("#E6E1FF")
        )
        listOf("🐱", "🐶", "🐰", "🐥").forEachIndexed { i, e ->
            val slot = FrameLayout(ctx).apply { clipChildren = false }
            val tv = TextView(ctx).apply {
                text = e
                textSize = 28f
                gravity = Gravity.CENTER
                includeFontPadding = false
                alpha = 0f
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(fills[i])
                    setStroke(dp(2), INK)
                }
                setLayerType(View.LAYER_TYPE_HARDWARE, null)
            }
            slot.addView(tv, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM))
            row.addView(slot, LinearLayout.LayoutParams(0, MATCH, 1f))
            tv.setOnClickListener {
                val loc = IntArray(2)
                tv.getLocationOnScreen(loc)
                Fx.burst(fxRoot, loc[0] + tv.width / 2f, loc[1].toFloat(), listOf("❤️", "💖", "🐾", "🐟"))
                tv.animate().scaleX(1.18f).scaleY(1.18f).setDuration(120).withEndAction {
                    tv.animate().scaleX(1f).scaleY(1f).setDuration(260)
                        .setInterpolator(OvershootInterpolator(3f)).start()
                }.start()
            }
            tv.post {
                tv.pivotX = tv.width / 2f
                tv.pivotY = tv.height.toFloat()
                tv.translationY = dpf(34f)
                tv.scaleX = 0.6f
                tv.scaleY = 0.6f
                tv.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                    .setStartDelay(150L + i * 100L).setDuration(520)
                    .setInterpolator(OvershootInterpolator(2.2f))
                    .withEndAction {
                        anim(ObjectAnimator.ofFloat(tv, "rotation", -6f, 6f).apply {
                            duration = 1300L + i * 150L
                            repeatCount = ValueAnimator.INFINITE
                            repeatMode = ValueAnimator.REVERSE
                            interpolator = AccelerateDecelerateInterpolator()
                        }).start()
                    }.start()
            }
        }
        return row
    }

    private fun buildPark(): View {
        val park = FrameLayout(ctx)
        val line = View(ctx).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.LINE
                setStroke(dp(3), Color.argb(56, 43, 35, 64), dpf(8f), dpf(6f))
            }
        }
        park.addView(line, FrameLayout.LayoutParams(MATCH, dp(3), Gravity.BOTTOM).apply { bottomMargin = dp(2) })
        val pets = listOf("🐱" to 11000L, "🐶" to 14000L, "🐰" to 9000L, "🐥" to 12000L)
        val views = pets.map { (e, _) ->
            val tv = TextView(ctx).apply {
                text = e
                textSize = 34f
            }
            park.addView(tv, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).apply { bottomMargin = dp(6) })
            tv.setOnClickListener {
                val loc = IntArray(2)
                tv.getLocationOnScreen(loc)
                Fx.burst(fxRoot, loc[0] + tv.width / 2f, loc[1].toFloat(), listOf("❤️", "💖", "🐾", "🐟"))
            }
            tv
        }
        var started = false
        park.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            if (!started && r - l > dp(120)) {
                started = true
                val span = (r - l - dp(52)).toFloat()
                views.forEachIndexed { i, tv ->
                    val walk = anim(ObjectAnimator.ofFloat(tv, "translationX", 0f, span).apply {
                        duration = pets[i].second
                        repeatCount = ValueAnimator.INFINITE
                        repeatMode = ValueAnimator.REVERSE
                        interpolator = LinearInterpolator()
                    })
                    walk.start()
                    walk.currentPlayTime = i * 2500L
                    anim(ObjectAnimator.ofFloat(tv, "translationY", 0f, -dpf(9f)).apply {
                        duration = 450
                        repeatCount = ValueAnimator.INFINITE
                        repeatMode = ValueAnimator.REVERSE
                    }).start()
                }
            }
        }
        return park
    }

    private fun paste() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()?.trim()
        if (t.isNullOrEmpty()) { toast("Clipboard is empty"); return }
        urlBox.setText(t)
        extractUrl(t)?.let { sheet(it) }
    }

    private fun getVideo() {
        val t = urlBox.text.toString().trim()
        if (t.isEmpty()) { toast("Paste a link or type something to search"); return }
        val u = extractUrl(t)
        if (u != null) sheet(u) else searchOn("YouTube", t)
    }

    private fun updateEngine() {
        engineStatus.text = "Updating… please wait"
        Thread {
            val r = Engine.update()
            runOnUiThread { engineStatus.text = r }
        }.start()
    }

    // ================================================================= BROWSE
    private fun buildBrowse(): View {
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        chipRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        sites.forEach { s ->
            val chip = TextView(ctx).apply {
                text = s.first
                tag = s.first
                typeface = Typeface.DEFAULT_BOLD
                textSize = 13f
                setTextColor(INK)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                background = Fx.flat(ctx, WHITE, 99)
                Fx.press(this, burstCb)
                setOnClickListener { showSite(s.first) }
            }
            chipRow.addView(chip, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        }
        col.add(HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            addView(chipRow)
        })

        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(8), dp(8))
        }
        searchBox = EditText(ctx).apply {
            hint = "Search this site or paste a link"
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_GO
            textSize = 14f
            setTextColor(INK)
            setPadding(dp(12), dp(9), dp(12), dp(9))
            Fx.cute(this, PAPER, 14, 0)
            setOnEditorActionListener { _, _, _ -> goSearch(); true }
        }
        bar.add(searchBox, w = 0, weight = 1f)
        bar.add(pill("Go", PINK, WHITE) { goSearch() }, w = WRAP, left = 8)
        col.add(bar)

        webHost = FrameLayout(ctx)
        col.add(webHost, h = 0, weight = 1f)

        val fab = TextView(ctx).apply {
            text = "⬇"
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(INK)
            Fx.cute(this, SUN, 31, 5)
        }
        Fx.press(fab, burstCb)
        fab.setOnClickListener { downloadCurrent() }
        anim(ObjectAnimator.ofFloat(fab, "translationY", 0f, -dpf(4f)).apply {
            duration = 700
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
        }).start()
        return FrameLayout(ctx).apply {
            addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
            addView(fab, FrameLayout.LayoutParams(dp(62), dp(67), Gravity.END or Gravity.BOTTOM).apply {
                setMargins(0, 0, dp(16), dp(18))
            })
        }
    }

    private fun showSite(name: String) {
        webs[site]?.evaluateJavascript("document.querySelectorAll('video,audio').forEach(function(v){v.pause()})", null)
        site = name
        val wv = webs.getOrPut(name) {
            makeWeb().also {
                webHost.addView(it, FrameLayout.LayoutParams(MATCH, MATCH))
                it.loadUrl(sites.first { s -> s.first == name }.second)
            }
        }
        webs.values.forEach { it.visibility = if (it === wv) View.VISIBLE else View.GONE }
        for (i in 0 until chipRow.childCount) {
            val c = chipRow.getChildAt(i) as TextView
            val on = c.tag == name
            c.background = Fx.flat(ctx, if (on) PINK else WHITE, 99)
            c.setTextColor(if (on) WHITE else INK)
        }
        if (tab != 1) show(1)
    }

    private fun searchOn(name: String, q: String) {
        showSite(name)
        val tpl = sites.first { it.first == name }.third
        webs[name]?.loadUrl(tpl.replace("%s", URLEncoder.encode(q, "UTF-8")))
    }

    private fun goSearch() {
        val t = searchBox.text.toString().trim()
        if (t.isEmpty()) return
        val wv = webs[site] ?: return
        if (t.startsWith("http://") || t.startsWith("https://")) wv.loadUrl(t)
        else if (!t.contains(' ') && t.contains('.')) wv.loadUrl("https://$t")
        else searchOn(site, t)
        searchBox.clearFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchBox.windowToken, 0)
    }

    private fun downloadCurrent() {
        val u = webs[site]?.url
        if (u.isNullOrEmpty() || !u.startsWith("http")) { toast("Open a video page first"); return }
        sheet(u)
    }

    private fun makeWeb(): WebView = WebView(ctx).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        settings.userAgentString = UA
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

        webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): android.webkit.WebResourceResponse? {
                if (Premium.tier() >= 2 && YtBlock.isAd(r.url.toString())) {
                    return android.webkit.WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            override fun onPageFinished(v: WebView, url: String?) {
                if (Premium.tier() >= 2 && url != null && url.contains("youtube.com")) v.evaluateJavascript(YtBlock.JS, null)
            }

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url.toString()
                return !(u.startsWith("http://") || u.startsWith("https://") || u.startsWith("about:"))
            }
        }
        webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(v: View, cb: CustomViewCallback) {
                if (fullView != null) { cb.onCustomViewHidden(); return }
                fullView = v
                fullCb = cb
                v.setBackgroundColor(Color.BLACK)
                (window.decorView as FrameLayout).addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            }

            override fun onHideCustomView() = exitFull()
        }
        setDownloadListener { u, ua, cd, mime, _ ->
            val name = URLUtil.guessFileName(u, cd, mime)
            toast("Downloading $name")
            Engine.direct(u, name, mime, CookieManager.getInstance().getCookie(u), ua ?: UA)
        }
        setOnLongClickListener { longPress(this) }
    }

    private fun exitFull() {
        val v = fullView ?: return
        (window.decorView as FrameLayout).removeView(v)
        fullView = null
        fullCb?.onCustomViewHidden()
        fullCb = null
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
    }

    private fun longPress(wv: WebView): Boolean {
        val r = wv.hitTestResult
        val extra = r.extra ?: return false
        when (r.type) {
            WebView.HitTestResult.IMAGE_TYPE ->
                pick("Image", listOf("💾 Save image" to { saveImage(extra) }))
            WebView.HitTestResult.SRC_ANCHOR_TYPE ->
                pick("Link", listOf("⬇ Download from this link" to { sheet(extra) }))
            WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                val h = object : Handler(Looper.getMainLooper()) {
                    override fun handleMessage(m: Message) {
                        val link = m.data.getString("url")
                        val items = ArrayList<Pair<String, () -> Unit>>()
                        items.add("💾 Save image" to { saveImage(extra) })
                        if (!link.isNullOrEmpty() && link.startsWith("http")) {
                            items.add("⬇ Download from this link" to { sheet(link) })
                        }
                        pick("Image", items)
                    }
                }
                wv.requestFocusNodeHref(h.obtainMessage())
            }
            else -> return false
        }
        return true
    }

    private fun pick(title: String, items: List<Pair<String, () -> Unit>>) {
        val box = sheetBox()
        box.add(txt(title, 18f, INK, true))
        val d = cardDialog(box)
        items.forEach { (label, act) ->
            box.add(btn(label, SUN, burst = false) { d.dismiss(); act() }, 12)
        }
        d.show()
    }

    private fun saveImage(u: String) {
        val name = if (u.startsWith("data:")) "image_${System.currentTimeMillis()}" else URLUtil.guessFileName(u, null, null)
        toast("Saving image…")
        Engine.direct(u, name, null, CookieManager.getInstance().getCookie(u), UA)
    }

    // ================================================================= DIALOGS / DOWNLOAD SHEET
    private fun cookieFile(url: String): File? {
        val host = Uri.parse(url).host ?: return null
        val c = CookieManager.getInstance().getCookie(url) ?: return null
        val dom = "." + host.split(".").takeLast(2).joinToString(".")
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        c.split(";").forEach {
            val p = it.trim()
            val k = p.substringBefore("=")
            val v = p.substringAfter("=", "")
            if (k.isNotEmpty()) sb.append("$dom\tTRUE\t/\tTRUE\t2147483647\t$k\t$v\n")
        }
        val f = File(cacheDir, "c_${System.nanoTime()}.txt")
        f.writeText(sb.toString())
        return f
    }

    internal fun sheetBox(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        Fx.cute(this, WHITE, 28, 5)
    }

    internal fun cardDialog(content: View): Dialog {
        val d = Dialog(ctx)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val wrap = FrameLayout(ctx).apply { setPadding(dp(12), dp(12), dp(12), dp(12)) }
        wrap.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        d.setContentView(wrap)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(MATCH, WRAP)
            setGravity(Gravity.BOTTOM)
        }
        return d
    }

    internal fun popup(title: String, msg: String) {
        val box = sheetBox()
        box.add(txt(title, 18f, INK, true))
        box.add(txt(msg, 13.5f), 8)
        val d = cardDialog(box)
        box.add(btn("OK", PINK, WHITE, burst = false) { d.dismiss() }, 14)
        d.show()
    }

    /** opens the quality sheet instantly; details load in the background */
    private fun sheet(url: String) {
        choose(url)
    }

    private fun chip(label: String, on: Boolean, click: () -> Unit) = TextView(ctx).apply {
        text = label
        textSize = 13.5f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (on) WHITE else INK)
        setPadding(dp(16), dp(9), dp(16), dp(9))
        Fx.cute(this, if (on) LAV else WHITE, 99, 3)
        Fx.press(this, null)
        setOnClickListener { click() }
    }

    private fun choose(url: String) {
        var heights: List<Int> = listOf(2160, 1440, 1080, 720, 480, 360)
        var title = "Your video"
        var thumbUrl: String? = null
        var audioMode = false
        val cap = Premium.maxHeight()
        var selH = heights.firstOrNull { cap == 0 || it <= cap } ?: (if (cap > 0) cap else 0)
        var selFmt = "mp3"
        var alive = true

        val box = sheetBox()
        val d = cardDialog(box)
        val frame = FrameLayout(ctx).apply {
            Fx.cute(this, PAPER, 16, 0)
            Fx.round(this, dpf(16f))
        }
        frame.addView(TextView(ctx).apply {
            text = "🎬"
            textSize = 40f
            gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(MATCH, MATCH))
        val iv = ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        frame.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        box.add(frame, h = dp(160))
        val titleTv = txt(title, 16f, INK, true).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        box.add(titleTv, 12)
        val note = txt("🔎 Loading details…", 12f, SOFT)
        box.add(note, 4)

        val seg = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            Fx.cute(this, PAPER, 99, 0)
        }
        val tabV = txt("🎬 Video", 14f, WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        val tabA = txt("♫ Audio", 14f, INK, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        seg.add(tabV, w = 0, weight = 1f)
        seg.add(tabA, w = 0, weight = 1f)
        box.add(seg, 12)
        val label = txt("", 11.5f, SOFT, true).apply { letterSpacing = 0.1f }
        box.add(label, 16)
        val chips = Flow(ctx, dp(10))
        box.add(chips, 10)

        fun paintSeg() {
            fun on(t: TextView, yes: Boolean) {
                t.setTextColor(if (yes) WHITE else INK)
                t.background = if (yes) Fx.flat(ctx, PINK, 99) else null
            }
            on(tabV, !audioMode)
            on(tabA, audioMode)
        }

        fun paintChips() {
            label.text = if (audioMode) "CHOOSE AUDIO FORMAT" else "CHOOSE VIDEO QUALITY"
            chips.removeAllViews()
            if (audioMode) {
                listOf("mp3" to "MP3", "m4a" to "M4A").forEach { (f, l) ->
                    chips.addView(chip(l, selFmt == f) { selFmt = f; paintChips() })
                }
            } else {
                (if (heights.isEmpty()) listOf(if (cap > 0) cap else 0) else heights).forEach { h ->
                    val locked = cap > 0 && h > cap
                    chips.addView(chip(if (h == 0) "Best" else if (locked) "${h}p 🔒" else "${h}p", selH == h && !locked) {
                        if (locked) {
                            d.dismiss()
                            more.upsell("${h}p is a Premium feature. Basic downloads go up to ${cap}p.")
                        } else { selH = h; paintChips() }
                    })
                }
            }
        }

        Fx.press(tabV, null)
        Fx.press(tabA, null)
        tabV.setOnClickListener { audioMode = false; paintSeg(); paintChips() }
        tabA.setOnClickListener { audioMode = true; paintSeg(); paintChips() }

        box.add(btn("⬇ DOWNLOAD", PINK, WHITE, burst = false) {
            if (Premium.left() <= 0) {
                d.dismiss()
                more.upsell("You used all ${Cfg.FREE_DAILY} free downloads today. Premium has no daily limit.")
                return@btn
            }
            val hh = if (audioMode) 0 else if (cap > 0 && (selH == 0 || selH > cap)) cap else selH
            Engine.start(url, title, thumbUrl, audioMode, selFmt, hh, cookieFile(url))
            d.dismiss()
            toast("Added to Downloads ⬇")
            more.afterDownload(Premium.count())
        }, 18)
        paintSeg()
        paintChips()
        d.setOnDismissListener { alive = false }
        d.show()
        Thread {
            val ck = cookieFile(url)
            try {
                val info = Engine.info(url, ck)
                ck?.delete()
                runOnUiThread {
                    if (!alive) return@runOnUiThread
                    val hs = (info.formats ?: emptyList())
                        .filter { (it.vcodec ?: "none") != "none" && it.height > 0 }
                        .map { it.height }
                        .distinct()
                        .sortedDescending()
                    if (hs.isNotEmpty()) {
                        heights = hs
                        if (!hs.contains(selH)) selH = hs.firstOrNull { cap == 0 || it <= cap } ?: (if (cap > 0) cap else 0)
                    }
                    title = info.title ?: title
                    titleTv.text = title
                    thumbUrl = info.thumbnail
                    Fx.image(iv, thumbUrl)
                    note.text = ""
                    paintChips()
                }
            } catch (e: Throwable) {
                ck?.delete()
                runOnUiThread {
                    if (alive) note.text = "Couldn't read the details, but you can still try to download."
                }
            }
        }.start()
    }

    // ================================================================= DOWNLOADS
    private fun buildDownloads(): View {
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(30), dp(16), dp(16))
        }
        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.add(TextView(ctx).apply {
            text = SpannableString("Downloads").apply {
                setSpan(BackgroundColorSpan(SUN), 4, 9, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(INK)
        }, w = 0, weight = 1f)
        head.add(pill("🧹 Clear finished", WHITE) { Engine.clearFinished() }, w = WRAP)
        col.add(head)
        dlEmpty = txt("🐱\nNo downloads yet.\nPaste a link on Home and tap Download!", 14f, SOFT).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(40), 0, 0)
        }
        col.add(dlEmpty)
        dlList = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.add(dlList, 6)
        return ScrollView(ctx).apply { addView(col) }
    }

    private fun requestRender() {
        if (renderPending) return
        renderPending = true
        ui.postDelayed({
            renderPending = false
            renderDownloads()
        }, 350)
    }

    private fun makeRow(j: Engine.Job): Row {
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            Fx.cute(this, WHITE, 22, 5)
        }
        val top = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val thumb = FrameLayout(ctx).apply {
            Fx.cute(this, PAPER, 12, 0)
            Fx.round(this, dpf(12f))
        }
        val emo = if (j.audio) "🎵" else if (j.kind == 1) "⬇️" else "🎬"
        thumb.addView(TextView(ctx).apply {
            text = emo
            textSize = 26f
            gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(MATCH, MATCH))
        val iv = ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        thumb.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        Fx.image(iv, j.thumb)
        top.add(thumb, w = dp(84), h = dp(56))
        val info = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val title = txt(j.title, 14f, INK, true).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        val status = txt("", 12f, SOFT)
        info.add(title)
        info.add(status, 3)
        top.add(info, w = 0, weight = 1f, left = 12)
        card.add(top)
        val bar = Bar(ctx)
        card.add(bar, 12, h = dp(14))
        val btns = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        card.add(btns, 12)
        card.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
        return Row(card, title, status, bar, btns)
    }

    private fun updateRow(r: Row, j: Engine.Job) {
        r.title.text = j.title
        r.status.text = when (j.state) {
            1 -> "✅ Saved to your phone"
            2 -> "❌ " + j.status
            3 -> "⏸ Paused · ${j.progress.toInt()}%"
            else -> j.status
        }
        r.bar.color = when (j.state) {
            1 -> MINT
            2 -> Color.parseColor("#FF9A9A")
            3 -> SUN
            else -> PINK
        }
        r.bar.value = if (j.state == 1) 100f else if (j.state == 0 && j.progress < 3f) 3f else j.progress
        if (r.state != j.state) {
            r.state = j.state
            r.btns.removeAllViews()
            when (j.state) {
                0 -> {
                    r.btns.add(pill("⏸ Pause", SUN) { Engine.pause(j) }, w = 0, weight = 1f)
                    r.btns.add(pill("✖ Cancel", WHITE) { Engine.remove(j, false) }, w = 0, weight = 1f, left = 10)
                }
                3 -> {
                    r.btns.add(pill("▶ Resume", MINT) { Engine.resume(j) }, w = 0, weight = 1f)
                    r.btns.add(pill("✖ Cancel", WHITE) { Engine.remove(j, false) }, w = 0, weight = 1f, left = 10)
                }
                1 -> {
                    r.btns.add(pill("▶ Open", MINT) { openJob(j) }, w = 0, weight = 1f)
                    r.btns.add(pill("Remove", WHITE) { Engine.remove(j, false) }, w = 0, weight = 1f, left = 10)
                }
                else -> {
                    r.btns.add(pill("🔁 Retry", SUN) { Engine.retry(j) }, w = 0, weight = 1f)
                    r.btns.add(pill("Remove", WHITE) { Engine.remove(j, false) }, w = 0, weight = 1f, left = 10)
                }
            }
        }
    }

    private fun renderDownloads() {
        if (!::dlList.isInitialized) return
        val jobs = Engine.jobs
        val ids = jobs.map { it.id }.toSet()
        rows.keys.filter { it !in ids }.forEach { id ->
            rows.remove(id)?.let { dlList.removeView(it.card) }
        }
        jobs.forEachIndexed { idx, j ->
            val r = rows.getOrPut(j.id) { makeRow(j) }
            if (r.card.parent == null) dlList.addView(r.card, idx)
            else if (dlList.getChildAt(idx) !== r.card) {
                dlList.removeView(r.card)
                dlList.addView(r.card, idx)
            }
            updateRow(r, j)
        }
        dlEmpty.visibility = if (jobs.isEmpty()) View.VISIBLE else View.GONE
        val n = jobs.count { it.state == 0 }
        badge.visibility = if (n > 0) View.VISIBLE else View.GONE
        badge.text = n.toString()
    }

    private fun openJob(j: Engine.Job) {
        val u = j.uri ?: return
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(u, j.mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Throwable) {
            toast("Saved in your Gallery / Downloads folder")
        }
    }
}
